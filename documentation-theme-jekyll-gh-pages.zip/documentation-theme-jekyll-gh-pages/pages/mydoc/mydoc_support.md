---
title: Support
tags: [getting_started, troubleshooting]
keywords: questions, troubleshooting, contact, support
last_updated: July 3, 2016
summary: "Contact me for any support issues."
sidebar: mydoc_sidebar
permalink: mydoc_support.html
folder: mydoc
---

Let me know about any bugs or other issues that you find. Just email me at <a href="mailto:tomjohnson1492@gmail.com">tomjohnson1492@gmail.com</a>. You can also [create issues directly within the Github repository here](https://github.com/tomjohnson1492/jekyll-doc/issues).

{% include links.html %}
